export interface Mykitchen
{
    vegetableid:number,
    vegetablename:string,
    vegetablecost:number,
    vegetableimg:string,
    vegetablequantity:number;
    vegetabletotal:number;
}