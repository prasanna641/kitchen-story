export interface Mykitchen1
{
    fruitid:number,
    fruitname:string,
    fruitcost:number,
    fruitimg:string,
    fruitquantity:number,
    fruittotal:number
}