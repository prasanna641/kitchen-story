export class Login{
    constructor(
         public email="",
         public password=""
         )
         {

         }
}
export interface Login
{
email:string;
password:string
}